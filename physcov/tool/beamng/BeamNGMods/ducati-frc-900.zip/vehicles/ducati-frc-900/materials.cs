
singleton Material(frc900_Matte__FF114182__sec_env_8_spec_)
{
   mapTo = "Matte__FF114182__sec_env_8_spec_";
   diffuseColor[0] = "0.164706 0.219608 0.305882 1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "28";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(frc900_vehicle_generic_tyrewallblack__spec_)
{
   mapTo = "vehicle_generic_tyrewallblack__spec_";
   diffuseColor[0] = "0.992157 0.992157 0.992157 1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "28";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/frc900/tyrewallblack.tga";
   materialTag0 = "Miscellaneous";
};

singleton Material(frc900_Matte__FF114182__sec_spec_)
{
   mapTo = "Matte__FF114182__sec_spec_";
   diffuseColor[0] = "0.03584 0.128 0.26112 1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "28";
   translucentBlendOp = "None";
};

singleton Material(frc900_pcj_lights_glass__env_8_spec_trans_)
{
   mapTo = "pcj_lights_glass__env_8_spec_trans_";
   diffuseColor[0] = "0.992157 0.992157 0.992157 0";
   specular[0] = "0.125 0.125 0.125 0";
   specularPower[0] = "31";
   translucentBlendOp = "Sub";
   diffuseMap[0] = "vehicles/frc900/pcj_lights_glass.tga";
   materialTag0 = "Miscellaneous";
   translucent = "1";
   alphaRef = "134";
   translucentZWrite = "1";
   specularMap[0] = "vehicles/frc900/pcj_lights_glass.tga";
   emissive[0] = "1";
   alphaTest = "1";
};

singleton Material(frc900_pcj_detail__spec_)
{
   mapTo = "pcj_detail__spec_";
   diffuseColor[0] = "0.996078 0.996078 0.996078 1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "28";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/frc900/pcj_detail.tga";
   normalMap[0] = "vehicles/frc900/frame_null.dds";
   materialTag0 = "Miscellaneous";
};

singleton Material(frc900_vehicle_generic_detail2__spec_)
{
   mapTo = "vehicle_generic_detail2__spec_";
   diffuseColor[0] = "1 1 1 1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "28";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/frc900/detail2.tga";
   normalMap[0] = "vehicles/frc900/frame_null.dds";
   specularMap[0] = "vehicles/frc900/detail2.tga";
   materialTag0 = "Miscellaneous";
};

singleton Material(frc900_targa__spec_)
{
   mapTo = "targa__spec_";
   diffuseColor[0] = "0.992157 0.992157 0.992157 1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "25";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/frc900/reg nm.tga";
   normalMap[0] = "vehicles/frc900/frame_null.dds";
   materialTag0 = "Miscellaneous";
};

singleton Material(frc900_vehicle_generic_alloy_silver_spe__prim_env_8_spec_)
{
   mapTo = "vehicle_generic_alloy_silver_spe__prim_env_8_spec_";
   diffuseColor[0] = "0.486275 0.486275 0.486275 1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "28";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/frc900/frame_null.dds";
   specularMap[0] = "vehicles/frc900/frame_null.dds";
   materialTag0 = "Miscellaneous";
};

singleton Material(frc900_vehicle_generic_carbon__spec_)
{
   mapTo = "vehicle_generic_carbon__spec_";
   diffuseColor[0] = "1 1 1 1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "28";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/frc900/carbon.tga";
   materialTag0 = "Miscellaneous";
};

singleton Material(frc900_vehiclelights128__spec_RR_)
{
   mapTo = "vehiclelights128__spec_RR_";
   diffuseColor[0] = "0.512 0.12288 0 1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "25";
   translucentBlendOp = "None";
};

singleton Material(frc900_vehiclelights128__spec_FR_)
{
   mapTo = "vehiclelights128__spec_FR_";
   diffuseColor[0] = "0 0.512 0.39936 1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "25";
   translucentBlendOp = "None";
};

singleton Material(frc900_pcj_badges__env_29_spec_)
{
   mapTo = "pcj_badges__env_29_spec_";
   diffuseColor[0] = "0.992157 0.992157 0.992157 1";
   specular[0] = "0.25 0.25 0.25 1";
   specularPower[0] = "28";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/frc900/pcj_badges.tga";
   normalMap[0] = "vehicles/frc900/frame_null.dds";
   materialTag0 = "Miscellaneous";
};

singleton Material(frc900_vehiclelights128__env_10_spec_RL_)
{
   mapTo = "vehiclelights128__env_10_spec_RL_";
   diffuseColor[0] = "0.584314 0.352941 0.00392157 1";
   specular[0] = "0.5 0.5 0.5 1";
   specularPower[0] = "7";
   translucentBlendOp = "None";
   materialTag0 = "Miscellaneous";
};

singleton Material(frc900_vehiclegeneric256__env_13_spec_)
{
   mapTo = "vehiclegeneric256__env_13_spec_";
   diffuseColor[0] = "0.64 0.64 0.64 1";
   specular[0] = "0.5 0.5 0.5 1";
   specularPower[0] = "7";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/frc900/sidecarmetal.tga";
   materialTag0 = "Miscellaneous";
};

singleton Material(frc900_vehiclegeneric256__prim_spec_)
{
   mapTo = "vehiclegeneric256__prim_spec_";
   diffuseColor[0] = "0.996078 0.996078 0.996078 1";
   specular[0] = "0.5 0.5 0.5 1";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/frc900/sidecarmetal.tga";
   materialTag0 = "Miscellaneous";
};

singleton Material(frc900_vehiclegrunge256__prim_spec_)
{
   mapTo = "vehiclegrunge256__prim_spec_";
   diffuseColor[0] = "0.64 0.64 0.64 1";
   specular[0] = "0.5 0.5 0.5 1";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/frc900/aluminium.jpg";
   specularPower[0] = "30";
   specularMap[0] = "vehicles/frc900/aluminium.jpg";
   materialTag0 = "Miscellaneous";
};

singleton Material(frc900_freeway92metal128__spec_)
{
   mapTo = "freeway92metal128__spec_";
   diffuseColor[0] = "0.764706 0.764706 0.764706 1";
   specular[0] = "0.5 0.5 0.5 1";
   specularPower[0] = "5";
   translucentBlendOp = "None";
   diffuseMap[0] = "vehicles/frc900/sidecarmetal.tga";
   materialTag0 = "Miscellaneous";
};
