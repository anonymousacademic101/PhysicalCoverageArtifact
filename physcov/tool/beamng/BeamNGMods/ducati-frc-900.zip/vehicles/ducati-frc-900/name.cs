%vehicleName = "Ducati FRC 900 (www.beamngdrivemods.com)";
